#include <iostream>
#include <vector>
#include <stdio.h>
#include <list>

#include "Salle.h"

using namespace std;

void afficher_carte(vector<Salle>* s);

int main()
{
    vector<Salle> cartes;
    Salle s;
    s.m_x=0;
    s.m_y=0;
    Bloc b;
    b.x=0;
    b.y=0;
    b.type=MUR;
    Bloc * pb=&b;
    Salle* ps=&s;
    Salle s2;
    s2.m_x=1;
    s2.m_y=0;
    Bloc c;
    c.x=0;
    c.y=0;
    c.type=AIR;
    Bloc c2;
    c2.x=0;
    c2.y=1;
    c2.type=PORTE;
    Bloc * pc=&c;
    Bloc * pc2=&c2;
    Salle* ps2=&s2;
    s.m_blocs.push_back(*pb);
    s2.m_blocs.push_back(*pc);
    s2.m_blocs.push_back(*pc2);
    cartes.push_back(*ps);
    cartes.push_back(*ps2);
    afficher_carte(&cartes);

    return 0;
}

void afficher_carte(vector<Salle>* s)
{
    int minx=0,miny=0,maxx=0,maxy=0;
    vector<Bloc> e;
    for(unsigned int i=0; i<(s->size()); i++)
    {
        Salle sal=(*s)[i];
        e=sal.m_blocs;
        for(unsigned int j=0; j<(e.size()); j++)
        {
            minx=min(minx,sal.m_x + e[j].x);
            maxx=max(maxx,sal.m_x + e[j].x);
            miny=min(miny,sal.m_y + e[j].y);
            maxy=max(maxy,sal.m_y + e[j].y);
        }
    }
    cout << "min x-y "<<minx<<"-"<<miny<<endl<< "max x-y "<<maxx<<"-"<<maxy<<endl;
    char t[maxx-minx+1][maxy-miny+1];
    for(int i=0; i<=maxx-minx; i++)
    {
        for(int j=0; j<=maxy-miny; j++)
            t[i][j]=' ';
    }
    for(unsigned int i=0; i<s->size(); i++)
    {
        Salle sal=(*s)[i];
        e=sal.m_blocs;
        for(unsigned int j=0; j<(e.size()); j++)
        {
            switch(e[j].type)
            {
            case VIDE:
                t[sal.m_x+e[j].x][sal.m_y+e[j].y]=' ';
                break;
            case AIR:
                t[sal.m_x+e[j].x][sal.m_y+e[j].y]='.';
                break;
            case MUR:
                t[sal.m_x+e[j].x][sal.m_y+e[j].y]='#';
                break;
            case PORTE:
                t[sal.m_x+e[j].x][sal.m_y+e[j].y]='/';
                break;
            default:
                t[sal.m_x+e[j].x][sal.m_y+e[j].y]='0';
                break;
            }
        }
    }
    for(int i=0; i<maxy-miny+1; i++)
    {
        for(int j=0; j<maxx-minx+1; j++)
        {
            printf("%c",t[j][i]);
        }
        printf("\n");
    }
}
