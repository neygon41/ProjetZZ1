#include "Salle.h"


Salle::Salle()
{
    //ctor


}

Salle::~Salle()
{
    //dtor
}
