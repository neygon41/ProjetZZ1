#ifndef SALLE_H
#define SALLE_H

#include <vector>
#include <list>

using namespace std;

typedef enum
{
    VIDE,
    AIR,
    MUR,
    PORTE
}Type_Bloc;

typedef struct
{
    Type_Bloc type;
    int x;
    int y;
} Bloc;

class Salle
{
    public:
        Salle();
        virtual ~Salle();
        vector<Bloc> m_blocs;
        int m_x;
        int m_y;
    protected:
    private:
};

#endif // SALLE_H
